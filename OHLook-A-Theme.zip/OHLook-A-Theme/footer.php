</div><!-- #content -->

        <div class="ohlookSpon passion"><a class="ohlookSponL" target="_blank" href="https://www.passionlighting.com/"></a></div>
        <div class="linkContainer">
            <div class="footerFlex">
                <p>OHLOOK Performing Arts Center is a 501(C)(3) Nonprofit Entity</p>
            </div>
            <div class="footerFlex socialLinks links">
                <a target="_blank" href="https://www.facebook.com/OHLOOKPAC/"><i class="fab fa-facebook"></i></a>
                <a target="_blank" href="https://twitter.com/OHLOOKpac"><i class="fab fa-twitter"></i></a>
                <a target="_blank" href="https://www.instagram.com/OHLOOKpac/"><i class="fab fa-instagram"></i></a>
            </div>
            <div class="footerFlex contactLinks links">
                <p><a href="contact.html">Contact Us</a></p>
                <p>1631 W Northwest Hwy, Grapevine, TX 76051</p>
                <p>(817)421-2825</p>
                
            </div>
        </div>

        <?php wp_footer(); ?>

</body>
</html>